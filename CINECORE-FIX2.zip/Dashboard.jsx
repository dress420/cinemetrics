import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { IMG_THUMB } from '../lib/tmdb'
import './Dashboard.css'

const SOURCES = [
  { key: 'tmdb',         label: 'TMDB',           color: '#01b4e4' },
  { key: 'toprated',     label: 'Top Rated',       color: '#4d9fd6' },
  { key: 'nowplaying',   label: 'In Cinemas',      color: '#6dc46d' },
  { key: 'rottentomato', label: 'Rotten Tomatoes', color: '#fa320a' },
  { key: 'metacritic',   label: 'Metacritic',      color: '#ffcc34' },
  { key: 'letterboxd',   label: 'Letterboxd',      color: '#00c030' },
]

const TIME_FILTERS = [
  { key: 'day',   label: 'Today' },
  { key: 'week',  label: 'This Week' },
  { key: 'month', label: 'This Month' },
  { key: 'year',  label: 'This Year' },
]

const API_KEY = import.meta.env.VITE_TMDB_API_KEY
const BASE = 'https://api.themoviedb.org/3'

async function fetchResults(source, timeFilter, page) {
  const now = new Date()
  const year = now.getFullYear()
  const month = String(now.getMonth() + 1).padStart(2, '0')
  const day   = String(now.getDate()).padStart(2, '0')
  const today = `${year}-${month}-${day}`

  const getWeekAgo = () => {
    const d = new Date(now)
    d.setDate(d.getDate() - 7)
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`
  }
  const getMonthStart = () => `${year}-${month}-01`
  const getYearStart  = () => `${year}-01-01`

  let url = ''

  if (source === 'tmdb') {
    // TMDB trending only supports day or week
    const period = timeFilter === 'day' ? 'day' : 'week'
    url = `${BASE}/trending/all/${period}?api_key=${API_KEY}&language=en-US&page=${page}`
  }
  else if (source === 'toprated') {
    // Top rated with optional year filter
    const yearParam = timeFilter === 'year' ? `&primary_release_year=${year}` : ''
    url = `${BASE}/movie/top_rated?api_key=${API_KEY}&language=en-US&page=${page}${yearParam}`
  }
  else if (source === 'nowplaying') {
    url = `${BASE}/movie/now_playing?api_key=${API_KEY}&language=en-US&page=${page}`
  }
  else if (source === 'rottentomato') {
    let dateParams = ''
    if (timeFilter === 'day')   dateParams = `&primary_release_date.gte=${today}&primary_release_date.lte=${today}`
    if (timeFilter === 'week')  dateParams = `&primary_release_date.gte=${getWeekAgo()}&primary_release_date.lte=${today}`
    if (timeFilter === 'month') dateParams = `&primary_release_date.gte=${getMonthStart()}&primary_release_date.lte=${today}`
    if (timeFilter === 'year')  dateParams = `&primary_release_date.gte=${getYearStart()}&primary_release_date.lte=${today}`
    url = `${BASE}/discover/movie?api_key=${API_KEY}&language=en-US&sort_by=popularity.desc&vote_count.gte=50&page=${page}${dateParams}`
  }
  else if (source === 'metacritic') {
    let dateParams = ''
    if (timeFilter === 'day')   dateParams = `&primary_release_date.gte=${today}&primary_release_date.lte=${today}`
    if (timeFilter === 'week')  dateParams = `&primary_release_date.gte=${getWeekAgo()}&primary_release_date.lte=${today}`
    if (timeFilter === 'month') dateParams = `&primary_release_date.gte=${getMonthStart()}&primary_release_date.lte=${today}`
    if (timeFilter === 'year')  dateParams = `&primary_release_date.gte=${getYearStart()}&primary_release_date.lte=${today}`
    url = `${BASE}/discover/movie?api_key=${API_KEY}&language=en-US&sort_by=vote_average.desc&vote_count.gte=100&page=${page}${dateParams}`
  }
  else if (source === 'letterboxd') {
    let dateParams = ''
    if (timeFilter === 'day')   dateParams = `&primary_release_date.gte=${today}&primary_release_date.lte=${today}`
    if (timeFilter === 'week')  dateParams = `&primary_release_date.gte=${getWeekAgo()}&primary_release_date.lte=${today}`
    if (timeFilter === 'month') dateParams = `&primary_release_date.gte=${getMonthStart()}&primary_release_date.lte=${today}`
    if (timeFilter === 'year')  dateParams = `&primary_release_date.gte=${getYearStart()}&primary_release_date.lte=${today}`
    url = `${BASE}/discover/movie?api_key=${API_KEY}&language=en-US&sort_by=vote_average.desc&vote_count.gte=50&with_original_language=en&page=${page}${dateParams}`
  }

  const res = await fetch(url)
  const data = await res.json()
  return {
    results: data.results || [],
    totalPages: Math.min(data.total_pages || 1, 50) // cap at 50 pages = 1000 results
  }
}

export default function Dashboard({ onAddFilm, refreshKey }) {
  const [stats, setStats]     = useState({ total: 0, watchtime: 0, avgRating: 0, gems: 0 })
  const [items, setItems]     = useState([])
  const [featured, setFeatured] = useState(null)
  const [source, setSource]   = useState('tmdb')
  const [timeFilter, setTimeFilter] = useState('week')
  const [page, setPage]       = useState(1)
  const [totalPages, setTotalPages] = useState(50)
  const [loading, setLoading] = useState(false)

  useEffect(() => { loadStats() }, [refreshKey])

  useEffect(() => {
    setPage(1)
    load(source, timeFilter, 1)
  }, [source, timeFilter])

  useEffect(() => {
    load(source, timeFilter, page)
  }, [page])

  const loadStats = async () => {
    const { data } = await supabase.from('films').select('runtime, user_rating, vote_average, status')
    if (!data) return
    const total = data.length
    const watchtime = Math.round(data.reduce((s, f) => s + (f.runtime || 100), 0) / 60)
    const rated = data.filter(f => f.user_rating)
    const avgRating = rated.length ? (rated.reduce((s, f) => s + f.user_rating, 0) / rated.length).toFixed(1) : 0
    const gems = data.filter(f => f.vote_average && f.vote_average < 7.5 && f.user_rating >= 8).length
    setStats({ total, watchtime, avgRating, gems })
  }

  const load = async (src, time, pg) => {
    setLoading(true)
    try {
      const { results, totalPages: tp } = await fetchResults(src, time, pg)
      setItems(results)
      setFeatured(results[0] || null)
      setTotalPages(tp)
    } catch (e) {
      console.error(e)
      setItems([])
    }
    setLoading(false)
  }

  const goToPage = (p) => {
    if (p < 1 || p > totalPages || p === page) return
    setPage(p)
  }

  const currentSource = SOURCES.find(s => s.key === source)
  const days = Math.round(stats.watchtime / 24)
  const globalRank = (i) => (page - 1) * 20 + i + 1

  const renderPageButtons = () => {
    let start = Math.max(1, page - 2)
    let end   = Math.min(totalPages, start + 4)
    if (end - start < 4) start = Math.max(1, end - 4)
    return Array.from({ length: end - start + 1 }, (_, i) => start + i).map(p => (
      <button key={p} className={`page-btn${page === p ? ' active' : ''}`} onClick={() => goToPage(p)}>{p}</button>
    ))
  }

  return (
    <div className="dashboard">
      <div className="stats-row">
        <div className="stat-card">
          <div className="stat-label">Films Logged</div>
          <div className="stat-value">{stats.total}<span className="stat-unit">films</span></div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Watchtime</div>
          <div className="stat-value">{stats.watchtime}<span className="stat-unit">hrs</span></div>
          <div className="stat-sub">{days} days of your life</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Avg Rating</div>
          <div className="stat-value">{stats.avgRating || '—'}<span className="stat-unit">/10</span></div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Hidden Gems</div>
          <div className="stat-value">{stats.gems}<span className="stat-unit">found</span></div>
        </div>
        <div className="stat-card add-card" onClick={onAddFilm}>
          <div className="add-icon">+</div>
          <div className="add-label">Add Film</div>
        </div>
      </div>

      <div className="trending-section">
        <div className="trending-controls">
          <div className="trending-controls-top">
            <div className="trending-title-label">TRENDING</div>
            <div className="source-tabs">
              {SOURCES.map(s => (
                <button
                  key={s.key}
                  className={`source-tab${source === s.key ? ' active' : ''}`}
                  style={source === s.key ? { borderColor: s.color, color: s.color } : {}}
                  onClick={() => { setSource(s.key) }}
                >{s.label}</button>
              ))}
            </div>
          </div>
          <div className="trending-controls-bottom">
            <div className="time-tabs">
              {TIME_FILTERS.map(t => (
                <button key={t.key} className={`time-tab${timeFilter === t.key ? ' active' : ''}`} onClick={() => { setTimeFilter(t.key) }}>
                  {t.label}
                </button>
              ))}
            </div>
            <div className="page-info mono">
              #{globalRank(0)}–#{globalRank(Math.min(19, items.length - 1))} · page {page} of {totalPages}
            </div>
          </div>
        </div>

        {loading ? (
          <div className="trending-loading">Loading {currentSource?.label}...</div>
        ) : items.length === 0 ? (
          <div className="trending-loading">No results for this time period</div>
        ) : (
          <div className="trending-layout">
            {featured && (
              <div
                className="trending-featured"
                style={{ backgroundImage: `url(https://image.tmdb.org/t/p/w1280${featured.backdrop_path || featured.poster_path})` }}
              >
                <div className="trending-featured-overlay">
                  <div className="trending-featured-badge" style={{ color: currentSource?.color }}>
                    #{globalRank(items.indexOf(featured))} ON {currentSource?.label?.toUpperCase()}
                  </div>
                  <div className="trending-featured-title">{featured.title || featured.name}</div>
                  <div className="trending-featured-meta">
                    {featured.media_type === 'tv' ? 'Series' : 'Film'} &middot;{' '}
                    {(featured.release_date || featured.first_air_date || '').split('-')[0]} &middot; ⭐ {featured.vote_average?.toFixed(1)}
                  </div>
                  {featured.overview && (
                    <div className="trending-featured-overview">{featured.overview.substring(0, 220)}...</div>
                  )}
                </div>
              </div>
            )}

            <div className="trending-list-side">
              {items.map((t, i) => (
                <div
                  key={t.id}
                  className={`trending-side-item${featured?.id === t.id ? ' featured-active' : ''}`}
                  onClick={() => setFeatured(t)}
                >
                  <div className="trending-side-rank" style={{ color: currentSource?.color }}>#{globalRank(i)}</div>
                  {t.poster_path
                    ? <img className="trending-side-thumb" src={`${IMG_THUMB}${t.poster_path}`} alt={t.title || t.name} />
                    : <div className="trending-side-no-img">{(t.title || t.name)?.charAt(0)}</div>
                  }
                  <div className="trending-side-info">
                    <div className="trending-side-title">{t.title || t.name}</div>
                    <div className="trending-side-meta mono">⭐ {t.vote_average?.toFixed(1)} · {(t.release_date || t.first_air_date || '').split('-')[0]}</div>
                  </div>
                </div>
              ))}

              <div className="pagination">
                <button className="page-btn" onClick={() => goToPage(1)} disabled={page === 1}>«</button>
                <button className="page-btn" onClick={() => goToPage(page - 1)} disabled={page === 1}>‹</button>
                {renderPageButtons()}
                <button className="page-btn" onClick={() => goToPage(page + 1)} disabled={page >= totalPages}>›</button>
                <button className="page-btn" onClick={() => goToPage(totalPages)} disabled={page >= totalPages}>»</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
