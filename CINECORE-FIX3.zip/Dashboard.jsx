import { useState, useEffect, useRef } from 'react'
import { supabase } from '../lib/supabase'
import { IMG_THUMB } from '../lib/tmdb'
import './Dashboard.css'

const API_KEY = import.meta.env.VITE_TMDB_API_KEY
const BASE    = 'https://api.themoviedb.org/3'

const SOURCES = [
  { key: 'tmdb',         label: 'TMDB',           color: '#01b4e4' },
  { key: 'toprated',     label: 'Top Rated',       color: '#4d9fd6' },
  { key: 'nowplaying',   label: 'In Cinemas',      color: '#6dc46d' },
  { key: 'rottentomato', label: 'Rotten Tomatoes', color: '#fa320a' },
  { key: 'metacritic',   label: 'Metacritic',      color: '#ffcc34' },
  { key: 'letterboxd',   label: 'Letterboxd',      color: '#00c030' },
]

const TIME_FILTERS = [
  { key: 'day',   label: 'Today'      },
  { key: 'week',  label: 'This Week'  },
  { key: 'month', label: 'This Month' },
  { key: 'year',  label: 'This Year'  },
]

function buildUrl(source, timeFilter, page) {
  const now   = new Date()
  const yyyy  = now.getFullYear()
  const mm    = String(now.getMonth() + 1).padStart(2, '0')
  const dd    = String(now.getDate()).padStart(2, '0')
  const today = `${yyyy}-${mm}-${dd}`

  const weekAgo = (() => {
    const d = new Date(now); d.setDate(d.getDate() - 7)
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`
  })()

  const dateRanges = {
    day:   `&primary_release_date.gte=${today}&primary_release_date.lte=${today}`,
    week:  `&primary_release_date.gte=${weekAgo}&primary_release_date.lte=${today}`,
    month: `&primary_release_date.gte=${yyyy}-${mm}-01&primary_release_date.lte=${today}`,
    year:  `&primary_release_date.gte=${yyyy}-01-01&primary_release_date.lte=${today}`,
  }

  const p = `&page=${page}`
  const base = `?api_key=${API_KEY}&language=en-US`

  switch (source) {
    case 'tmdb':
      return `${BASE}/trending/all/${timeFilter === 'day' ? 'day' : 'week'}${base}${p}`
    case 'toprated':
      return `${BASE}/movie/top_rated${base}${p}${timeFilter === 'year' ? `&primary_release_year=${yyyy}` : ''}`
    case 'nowplaying':
      return `${BASE}/movie/now_playing${base}${p}`
    case 'rottentomato':
      return `${BASE}/discover/movie${base}&sort_by=popularity.desc&vote_count.gte=20${p}${dateRanges[timeFilter]}`
    case 'metacritic':
      return `${BASE}/discover/movie${base}&sort_by=vote_average.desc&vote_count.gte=50${p}${dateRanges[timeFilter]}`
    case 'letterboxd':
      return `${BASE}/discover/movie${base}&sort_by=vote_average.desc&vote_count.gte=30&with_original_language=en${p}${dateRanges[timeFilter]}`
    default:
      return `${BASE}/trending/all/week${base}${p}`
  }
}

export default function Dashboard({ onAddFilm, refreshKey }) {
  const [stats,      setStats]      = useState({ total: 0, watchtime: 0, avgRating: 0, gems: 0 })
  const [items,      setItems]      = useState([])
  const [featured,   setFeatured]   = useState(null)
  const [source,     setSource]     = useState('tmdb')
  const [timeFilter, setTimeFilter] = useState('week')
  const [page,       setPage]       = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [loading,    setLoading]    = useState(false)

  // single ref to cancel stale fetches
  const fetchId = useRef(0)

  useEffect(() => { loadStats() }, [refreshKey])

  // Single effect - runs whenever source, timeFilter, OR page changes
  useEffect(() => {
    const id = ++fetchId.current
    setLoading(true)
    setItems([])

    const url = buildUrl(source, timeFilter, page)

    fetch(url)
      .then(r => r.json())
      .then(data => {
        if (id !== fetchId.current) return // stale, ignore
        const results = data.results || []
        const tp = Math.min(data.total_pages || 1, 50)
        setTotalPages(tp)
        setItems(results)
        setFeatured(results[0] || null)
        setLoading(false)
      })
      .catch(() => {
        if (id !== fetchId.current) return
        setItems([])
        setLoading(false)
      })
  }, [source, timeFilter, page])

  const loadStats = async () => {
    const { data } = await supabase.from('films').select('runtime, user_rating, vote_average')
    if (!data) return
    const total    = data.length
    const watchtime = Math.round(data.reduce((s, f) => s + (f.runtime || 100), 0) / 60)
    const rated    = data.filter(f => f.user_rating)
    const avgRating = rated.length ? (rated.reduce((s, f) => s + f.user_rating, 0) / rated.length).toFixed(1) : 0
    const gems     = data.filter(f => f.vote_average && f.vote_average < 7.5 && f.user_rating >= 8).length
    setStats({ total, watchtime, avgRating, gems })
  }

  const changeSource = (s) => { setSource(s); setPage(1) }
  const changeTime   = (t) => { setTimeFilter(t); setPage(1) }
  const goToPage     = (p) => { if (p >= 1 && p <= totalPages) setPage(p) }

  const src  = SOURCES.find(s => s.key === source)
  const days = Math.round(stats.watchtime / 24)
  const rank = (i) => (page - 1) * 20 + i + 1

  const pageButtons = () => {
    const total = totalPages
    let start = Math.max(1, page - 2)
    let end   = Math.min(total, start + 4)
    if (end - start < 4) start = Math.max(1, end - 4)
    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  return (
    <div className="dashboard">
      <div className="stats-row">
        <div className="stat-card">
          <div className="stat-label">Films Logged</div>
          <div className="stat-value">{stats.total}<span className="stat-unit">films</span></div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Watchtime</div>
          <div className="stat-value">{stats.watchtime}<span className="stat-unit">hrs</span></div>
          <div className="stat-sub">{days} days of your life</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Avg Rating</div>
          <div className="stat-value">{stats.avgRating || '—'}<span className="stat-unit">/10</span></div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Hidden Gems</div>
          <div className="stat-value">{stats.gems}<span className="stat-unit">found</span></div>
        </div>
        <div className="stat-card add-card" onClick={onAddFilm}>
          <div className="add-icon">+</div>
          <div className="add-label">Add Film</div>
        </div>
      </div>

      <div className="trending-section">
        <div className="trending-controls">
          <div className="trending-controls-top">
            <span className="trending-title-label">TRENDING</span>
            <div className="source-tabs">
              {SOURCES.map(s => (
                <button
                  key={s.key}
                  className={`source-tab${source === s.key ? ' active' : ''}`}
                  style={source === s.key ? { borderColor: s.color, color: s.color } : {}}
                  onClick={() => changeSource(s.key)}
                >{s.label}</button>
              ))}
            </div>
          </div>
          <div className="trending-controls-bottom">
            <div className="time-tabs">
              {TIME_FILTERS.map(t => (
                <button
                  key={t.key}
                  className={`time-tab${timeFilter === t.key ? ' active' : ''}`}
                  onClick={() => changeTime(t.key)}
                >{t.label}</button>
              ))}
            </div>
            <span className="page-info mono">
              {loading ? 'Loading...' : `#${rank(0)}–#${rank(items.length - 1)} · page ${page} of ${totalPages}`}
            </span>
          </div>
        </div>

        {loading ? (
          <div className="trending-loading">Loading {src?.label}...</div>
        ) : items.length === 0 ? (
          <div className="trending-loading">No results for this filter</div>
        ) : (
          <div className="trending-layout">
            {featured && (
              <div
                className="trending-featured"
                style={{ backgroundImage: `url(https://image.tmdb.org/t/p/w1280${featured.backdrop_path || featured.poster_path})` }}
              >
                <div className="trending-featured-overlay">
                  <div className="trending-featured-badge" style={{ color: src?.color }}>
                    #{rank(items.indexOf(featured))} ON {src?.label?.toUpperCase()}
                  </div>
                  <div className="trending-featured-title">{featured.title || featured.name}</div>
                  <div className="trending-featured-meta">
                    {featured.media_type === 'tv' ? 'Series' : 'Film'} &middot;{' '}
                    {(featured.release_date || featured.first_air_date || '—').split('-')[0]} &middot; ⭐ {featured.vote_average?.toFixed(1)}
                  </div>
                  {featured.overview && (
                    <div className="trending-featured-overview">{featured.overview.slice(0, 220)}...</div>
                  )}
                </div>
              </div>
            )}

            <div className="trending-list-side">
              {items.map((t, i) => (
                <div
                  key={t.id}
                  className={`trending-side-item${featured?.id === t.id ? ' featured-active' : ''}`}
                  onClick={() => setFeatured(t)}
                >
                  <div className="trending-side-rank" style={{ color: src?.color }}>#{rank(i)}</div>
                  {t.poster_path
                    ? <img className="trending-side-thumb" src={`${IMG_THUMB}${t.poster_path}`} alt={t.title || t.name} />
                    : <div className="trending-side-no-img">{(t.title || t.name)?.charAt(0)}</div>
                  }
                  <div className="trending-side-info">
                    <div className="trending-side-title">{t.title || t.name}</div>
                    <div className="trending-side-meta mono">⭐ {t.vote_average?.toFixed(1)} · {(t.release_date || t.first_air_date || '').split('-')[0]}</div>
                  </div>
                </div>
              ))}

              <div className="pagination">
                <button className="page-btn" onClick={() => goToPage(1)} disabled={page === 1}>«</button>
                <button className="page-btn" onClick={() => goToPage(page - 1)} disabled={page === 1}>‹</button>
                {pageButtons().map(p => (
                  <button key={p} className={`page-btn${page === p ? ' active' : ''}`} onClick={() => goToPage(p)}>{p}</button>
                ))}
                <button className="page-btn" onClick={() => goToPage(page + 1)} disabled={page >= totalPages}>›</button>
                <button className="page-btn" onClick={() => goToPage(totalPages)} disabled={page >= totalPages}>»</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
